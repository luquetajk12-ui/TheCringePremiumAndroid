THE CRINGE PREMIUM — GERAR APK SÓ COM O CELULAR

IMPORTANTE
Este pacote não contém um APK já compilado. Ele prepara uma compilação gratuita na nuvem usando GitHub Actions, sem computador. Você precisará de uma conta GitHub e internet. O APK resultante será um APK de depuração para uso pessoal.

ARQUIVOS
- TheCringePremiumAndroid.zip: código-fonte Android que será compilado.
- build-apk.yml: workflow de compilação para GitHub Actions.

PASSO 1 — CRIAR UM REPOSITÓRIO
1. No Chrome do celular, entre em https://github.com e faça login/crie sua conta.
2. Crie um repositório novo com o nome TheCringePremiumAndroid.
3. Selecione Public se quiser seguir o caminho gratuito mais simples para GitHub Actions. Não envie conversas pessoais nem dados privados para o repositório.
4. Crie o repositório.

PASSO 2 — ENVIAR O ZIP DO PROJETO
1. Dentro do repositório, toque em Add file > Upload files.
2. Envie o arquivo TheCringePremiumAndroid.zip deste pacote (não precisa extrair).
3. Faça Commit changes na branch main.

PASSO 3 — CRIAR O WORKFLOW
1. No repositório, toque em Add file > Create new file.
2. No campo do nome do arquivo, digite exatamente: .github/workflows/build-apk.yml
3. Abra o arquivo build-apk.yml deste pacote em um editor de texto no celular, copie todo o conteúdo e cole no editor do GitHub. Se for mais fácil, o conteúdo também está no arquivo de texto incluído no pacote.
4. Faça Commit changes na branch main.

PASSO 4 — AGUARDAR A COMPILAÇÃO
1. Abra a aba Actions do repositório.
2. Toque em “Build The Cringe Premium APK”.
3. Abra a execução mais recente e espere todos os passos ficarem verdes. Se falhar, abra o passo vermelho e consulte a mensagem de erro.
4. Quando terminar, volte ao resumo da execução e procure Artifacts.
5. Baixe “TheCringePremium-debug-apk”. O GitHub baixa um ZIP contendo app-debug.apk.

PASSO 5 — INSTALAR NO ANDROID
1. Extraia o ZIP do artifact usando o app Arquivos do celular.
2. Toque em app-debug.apk.
3. Se o Android bloquear, autorize temporariamente “Instalar apps desconhecidos” para o app usado para abrir o APK, somente se você confia no arquivo que acabou de gerar.
4. Confirme a instalação. Depois, abra The Cringe Premium na lista de aplicativos.

PRIVACIDADE E LIMITAÇÕES
- O código-fonte fica no repositório escolhido. Não faça upload da exportação do WhatsApp; o ZIP contém somente o código do app.
- Um repositório público torna o código visível a outras pessoas. Use apenas o código-fonte, nunca suas conversas pessoais.
- O APK gerado é de depuração, não é uma versão assinada para publicação na Play Store.
- O app usa uma interface HTML dentro de uma atividade Android. Análise de relacionamento por IA externa ainda não está conectada; as funções são as que estão implementadas no código.
- A compilação pode falhar se o GitHub alterar seus serviços ou se houver incompatibilidade de dependências. Nesse caso, abra os logs do Actions.
